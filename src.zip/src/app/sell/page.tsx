"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Fish, Loader2, ImagePlus } from "lucide-react";
import type { User } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/client";

const GROUP_ORDER = [
  "Tetras & Characins",
  "Rasboras & Small Cyprinids",
  "Danios",
  "Barbs",
  "Livebearers",
  "Gouramis & Bettas",
  "Corydoras & Relatives",
  "Other Catfish",
  "Plecos (L-number Catfish)",
  "Loaches",
  "Cichlids - New World",
  "Cichlids - African Rift Lake",
  "Rainbowfish",
  "Killifish",
  "Oddballs & Specialty",
  "Goldfish & Coldwater",
  "Shrimp",
  "Snails",
  "Crayfish",
];

function slugify(text: string) {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

type SpeciesOption = {
  slug: string;
  common_name: string;
  group_name: string | null;
};

export default function SellPage() {
  const router = useRouter();
  const supabase = useMemo(() => createClient(), []);

  const [checkingAuth, setCheckingAuth] = useState(true);
  const [user, setUser] = useState<User | null>(null);

  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [stock, setStock] = useState("");
  const [description, setDescription] = useState("");
  const [isLiveAnimal, setIsLiveAnimal] = useState(false);
  const [speciesSlug, setSpeciesSlug] = useState("");
  const [speciesList, setSpeciesList] = useState<SpeciesOption[]>([]);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [converting, setConverting] = useState(false);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUser(data.user);
      setCheckingAuth(false);
    });
  }, [supabase]);

  useEffect(() => {
    supabase
      .from("species")
      .select("slug, common_name, group_name")
      .order("common_name")
      .then(({ data }) => setSpeciesList(data ?? []));
  }, [supabase]);

  const groupedSpecies = useMemo(() => {
    const map = new Map<string, { slug: string; common_name: string }[]>();
    for (const sp of speciesList) {
      const key = sp.group_name ?? "Other";
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push({ slug: sp.slug, common_name: sp.common_name });
    }
    const orderedKeys = [
      ...GROUP_ORDER.filter((g) => map.has(g)),
      ...[...map.keys()].filter((g) => !GROUP_ORDER.includes(g)).sort(),
    ];
    return orderedKeys.map((g) => [g, map.get(g)!] as const);
  }, [speciesList]);

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const selected = e.target.files?.[0];
    if (!selected) return;
    setError(null);

    let file = selected;
    const isHeic =
      /image\/hei[cf]/i.test(selected.type) || /\.(heic|heif)$/i.test(selected.name);

    if (isHeic) {
      setConverting(true);
      try {
        const heic2any = (await import("heic2any")).default;
        const result = await heic2any({
          blob: selected,
          toType: "image/jpeg",
          quality: 0.9,
        });
        const blob = Array.isArray(result) ? result[0] : result;
        file = new File([blob], selected.name.replace(/\.(heic|heif)$/i, ".jpg"), {
          type: "image/jpeg",
        });
      } catch (err) {
        console.error("HEIC conversion failed:", err);
        setError("That photo couldn't be processed. Try a JPG or PNG instead.");
        setConverting(false);
        return;
      }
      setConverting(false);
    }

    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError("Please give your listing a name.");
      return;
    }
    const priceNum = parseFloat(price);
    if (isNaN(priceNum) || priceNum < 0) {
      setError("Please enter a valid price.");
      return;
    }

    setSubmitting(true);
    try {
      const { data: userData } = await supabase.auth.getUser();
      const currentUser = userData.user;
      if (!currentUser) {
        setError("You need to be signed in to create a listing.");
        setSubmitting(false);
        return;
      }

      let storeId: string;
      const { data: existingStore } = await supabase
        .from("stores")
        .select("id")
        .eq("owner_id", currentUser.id)
        .limit(1)
        .maybeSingle();

      if (existingStore) {
        storeId = existingStore.id;
      } else {
        const username =
          currentUser.user_metadata?.username ||
          currentUser.email?.split("@")[0] ||
          "seller";
        const storeSlug = `${slugify(username)}-${currentUser.id.slice(0, 6)}`;
        const { data: newStore, error: storeError } = await supabase
          .from("stores")
          .insert({
            owner_id: currentUser.id,
            name: `${username}'s Shop`,
            slug: storeSlug,
          })
          .select("id")
          .single();
        if (storeError) throw storeError;
        storeId = newStore.id;
      }

      let imageUrls: string[] = [];
      if (imageFile) {
        const fileExt = imageFile.name.split(".").pop()?.toLowerCase() || "jpg";
        const filePath = `${currentUser.id}/${Date.now()}-${Math.random()
          .toString(36)
          .slice(2, 8)}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from("product-images")
          .upload(filePath, imageFile);
        if (uploadError) throw uploadError;
        const { data: publicUrlData } = supabase.storage
          .from("product-images")
          .getPublicUrl(filePath);
        imageUrls = [publicUrlData.publicUrl];
      }

      const productSlug = `${slugify(name)}-${Math.random().toString(36).slice(2, 8)}`;
      const { data: newProduct, error: productError } = await supabase
        .from("products")
        .insert({
          store_id: storeId,
          name: name.trim(),
          slug: productSlug,
          description: description.trim() || null,
          price: priceNum,
          stock: stock === "" ? null : parseInt(stock, 10),
          is_live_animal: isLiveAnimal,
          is_active: true,
          images: imageUrls.length ? imageUrls : null,
          species_slug: speciesSlug || null,
        })
        .select("slug")
        .single();
      if (productError) throw productError;

      router.push(`/marketplace/${newProduct.slug}`);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Something went wrong creating your listing."
      );
      setSubmitting(false);
    }
  }

  if (checkingAuth) {
    return (
      <main className="min-h-screen pt-28 pb-20 px-6 flex items-center justify-center">
        <Loader2 className="w-6 h-6 text-ocean-500 animate-spin" />
      </main>
    );
  }

  if (!user) {
    return (
      <main className="min-h-screen pt-28 pb-20 px-6">
        <div className="max-w-md mx-auto text-center py-20">
          <Fish className="w-10 h-10 text-ocean-600 mx-auto mb-4" />
          <h1 className="font-display text-2xl text-white mb-2">Sign in to sell</h1>
          <p className="text-ocean-400 mb-6">
            You need an account to create a listing. It only takes a moment.
          </p>
          <Link
            href="/login"
            className="inline-block px-6 py-3 rounded-xl bg-ocean-700 text-white hover:bg-ocean-600 transition-colors"
          >
            Sign in
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen pt-28 pb-20 px-6">
      <div className="max-w-2xl mx-auto">
        <p className="text-xs font-mono tracking-widest text-ocean-500 uppercase mb-3">
          New Listing
        </p>
        <h1 className="font-display text-4xl text-white mb-3">List something for sale</h1>
        <p className="text-ocean-400 mb-10">
          Fill in the details below and add a photo to make it shine.
        </p>

        {error && (
          <div className="rounded-xl border border-coral-500/40 bg-coral-500/10 px-5 py-4 text-coral-300 mb-6">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm text-ocean-300 mb-2">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Galaxy Koi Betta"
              className="w-full rounded-xl bg-ocean-900/60 border border-ocean-800/60 px-4 py-3 text-white placeholder-ocean-600 focus:outline-none focus:border-ocean-500 transition-colors"
            />
          </div>

          <div>
            <label className="block text-sm text-ocean-300 mb-2">Species (optional)</label>
            <select
              value={speciesSlug}
              onChange={(e) => setSpeciesSlug(e.target.value)}
              className="w-full rounded-xl bg-ocean-900/60 border border-ocean-800/60 px-4 py-3 text-white focus:outline-none focus:border-ocean-500 transition-colors"
            >
              <option value="">— Not applicable —</option>
              {groupedSpecies.map(([group, items]) => (
                <optgroup key={group} label={group}>
                  {items.map((sp) => (
                    <option key={sp.slug} value={sp.slug}>
                      {sp.common_name}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>
            <p className="text-xs text-ocean-500 mt-2">
              Link this listing to a species and it will appear on that species&apos;
              page in the database.
            </p>
          </div>

          <div>
            <label className="block text-sm text-ocean-300 mb-2">Photo (optional)</label>
            <label className="block cursor-pointer rounded-xl border border-dashed border-ocean-700/60 bg-ocean-900/40 hover:border-ocean-500 transition-colors overflow-hidden">
              {converting ? (
                <div className="h-56 flex flex-col items-center justify-center text-ocean-400">
                  <Loader2 className="w-8 h-8 mb-2 animate-spin" />
                  <span className="text-sm">Converting photo…</span>
                </div>
              ) : imagePreview ? (
                <img src={imagePreview} alt="Preview" className="w-full h-56 object-cover" />
              ) : (
                <div className="h-56 flex flex-col items-center justify-center text-ocean-500">
                  <ImagePlus className="w-8 h-8 mb-2" />
                  <span className="text-sm">Click to add a photo</span>
                </div>
              )}
              <input
                type="file"
                accept="image/*,.heic,.heif"
                onChange={handleFileChange}
                className="hidden"
              />
            </label>
            {imagePreview && !converting && (
              <p className="text-xs text-ocean-500 mt-2">
                Click the image to choose a different one.
              </p>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm text-ocean-300 mb-2">Price (USD)</label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="45.00"
                className="w-full rounded-xl bg-ocean-900/60 border border-ocean-800/60 px-4 py-3 text-white placeholder-ocean-600 focus:outline-none focus:border-ocean-500 transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm text-ocean-300 mb-2">Stock (optional)</label>
              <input
                type="number"
                min="0"
                value={stock}
                onChange={(e) => setStock(e.target.value)}
                placeholder="1"
                className="w-full rounded-xl bg-ocean-900/60 border border-ocean-800/60 px-4 py-3 text-white placeholder-ocean-600 focus:outline-none focus:border-ocean-500 transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm text-ocean-300 mb-2">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={5}
              placeholder="Tell buyers about it — size, care, what makes it special."
              className="w-full rounded-xl bg-ocean-900/60 border border-ocean-800/60 px-4 py-3 text-white placeholder-ocean-600 focus:outline-none focus:border-ocean-500 transition-colors resize-none"
            />
          </div>

          <label className="flex items-center gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={isLiveAnimal}
              onChange={(e) => setIsLiveAnimal(e.target.checked)}
              className="w-4 h-4 rounded border-ocean-700 bg-ocean-900 accent-brine-500"
            />
            <span className="text-sm text-ocean-300">This is a live animal</span>
          </label>

          <button
            type="submit"
            disabled={submitting || converting}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-ocean-700 text-white font-medium hover:bg-ocean-600 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
            {submitting ? "Creating…" : "Create listing"}
          </button>
        </form>
      </div>
    </main>
  );
}