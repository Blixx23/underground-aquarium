"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Heart } from "lucide-react";
import { createClient } from "@/lib/supabase/client";

export default function StoreFavoriteButton({ storeId }: { storeId: string }) {
  const [supabase] = useState(() => createClient());
  const router = useRouter();

  const [meId, setMeId] = useState<string | null>(null);
  const [isFavorited, setIsFavorited] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let active = true;
    supabase.auth.getUser().then(async ({ data }) => {
      if (!active) return;
      const uid = data.user?.id ?? null;
      setMeId(uid);
      if (uid) {
        const { data: row } = await supabase
          .from("store_favorites")
          .select("user_id")
          .eq("user_id", uid)
          .eq("fish_store_id", storeId)
          .maybeSingle();
        if (active) setIsFavorited(!!row);
      }
      if (active) setLoaded(true);
    });
    return () => {
      active = false;
    };
  }, [supabase, storeId]);

  async function toggle() {
    if (busy) return;
    if (!meId) {
      router.push("/login");
      return;
    }
    setBusy(true);
    const next = !isFavorited;
    setIsFavorited(next); // optimistic
    try {
      if (next) {
        const { error } = await supabase
          .from("store_favorites")
          .insert({ user_id: meId, fish_store_id: storeId });
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("store_favorites")
          .delete()
          .eq("user_id", meId)
          .eq("fish_store_id", storeId);
        if (error) throw error;
      }
    } catch {
      setIsFavorited(!next); // revert if it failed
    } finally {
      setBusy(false);
    }
  }

  return (
    <button
      onClick={toggle}
      disabled={busy || !loaded}
      aria-pressed={isFavorited}
      className={
        "inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-colors disabled:opacity-50 " +
        (isFavorited
          ? "bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/25"
          : "border border-white/10 text-ocean-200 hover:text-white hover:border-white/20")
      }
    >
      <Heart className={"w-4 h-4 " + (isFavorited ? "fill-current" : "")} />
      {isFavorited ? "Favorited" : "Favorite"}
    </button>
  );
}